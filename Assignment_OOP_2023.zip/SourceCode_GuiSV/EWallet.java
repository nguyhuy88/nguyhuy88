public class EWallet implements Payment, Transfer {
	// code here
}
