public class BankAccount implements Payment, Transfer{
    // code here
}
