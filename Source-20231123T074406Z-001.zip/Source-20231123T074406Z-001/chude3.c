#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>

int luaChon(int bien1, int bien2, char selection) {
    if (selection == '+') {
        return bien1 + bien2;
    } else if (selection == '-') {
        return bien1 - bien2;
    } else if (selection == '*') {
        return bien1 * bien2;
    } else if (selection == '/') {
        if (bien2 != 0) {
            return bien1 / bien2;
        } else {
            printf("Lỗi: Chia cho số 0\n");
            return 0;
        }
    } else {
        printf("Lỗi: Phép tính không hợp lệ\n");
        return 0;
    }
}

int main() {
    int pipe_fd[2];

    if (pipe(pipe_fd) == -1) {
        perror("Lỗi khi tạo ống truyền thông");
        exit(EXIT_FAILURE);
    }

    pid_t pid = fork();

    if (pid == -1) {
        perror("Lỗi khi tạo tiến trình con");
        exit(EXIT_FAILURE);
    }

    if (pid == 0) {
        close(pipe_fd[1]);

        int bien1, bien2, result;
        char selection;

        while (1) {
            if (read(pipe_fd[0], &bien1, sizeof(int)) <= 0) {
                break;
            }

            read(pipe_fd[0], &bien2, sizeof(int));
            read(pipe_fd[0], &selection, sizeof(char));

            if (bien1 == -1) {
                break; 
            }

            result = luaChon(bien1, bien2, selection);
            write(pipe_fd[1], &result, sizeof(int));
        }

        close(pipe_fd[0]);
    } else {
        close(pipe_fd[0]);

        int bien1, bien2, result;
        char selection;
        char expression[256];

        do {
            printf("Nhập số nguyên 1: ");
            fflush(stdout);
            scanf("%d", &bien1);

            printf("Nhập số nguyên 2: ");
            fflush(stdout);
            scanf("%d", &bien2);

            printf("Nhập phép tính (+, -, *, /): ");
            fflush(stdout);
            scanf(" %c", &selection);

            write(pipe_fd[1], &bien1, sizeof(int));
            write(pipe_fd[1], &bien2, sizeof(int));
            write(pipe_fd[1], &selection, sizeof(char));

            read(pipe_fd[0], &result, sizeof(int));
            printf("Kết quả: %d\n", result);

        } while (1);

        int endSignal = -1;
        write(pipe_fd[1], &endSignal, sizeof(int));

        close(pipe_fd[1]);
        wait(NULL);
    }

    return 0;
}
