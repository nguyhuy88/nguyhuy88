import java.util.ArrayList;

public class Rating {
    // Thuộc tính
    private int userId;
    private int movieId;
    private int ratingScore;
    private long timestamp;
    private String errorMsg;

    public Rating(int userId, int movieId, int ratingScore, long timestamp, String errorMsg) {
        this.userId = userId;
        this.movieId = movieId;
        this.ratingScore = ratingScore;
        this.timestamp = timestamp;
        // this.errorMsg = errorMsg;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getallMovies() {
        return movieId;
    }

    public int getMovieId() {
        return movieId;
    }

    public void setMovieId(int movieId) {
        this.movieId = movieId;
    }

    public int getRatingScore() {
        return ratingScore;
    }

    public void setRatingScore(int ratingScore) {
        this.ratingScore = ratingScore;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public Rating(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public String getErrorMessage() {
        return errorMsg;
    }
    
    // public static ArrayList<Integer> getFavorites(ArrayList<Rating> ratings) {
    //     return null;
    // }

    @Override
    public String toString() {
        return "Rating[" + "maUser: " + userId + ", maMovie:" + movieId + ", ratingPointed=" + ratingScore
                + ", timestamp=" + timestamp + ']';
    }

    public static ArrayList<Integer> get_HUY_Favorites(ArrayList<Rating> ratings) {
        return null;
    }
}
