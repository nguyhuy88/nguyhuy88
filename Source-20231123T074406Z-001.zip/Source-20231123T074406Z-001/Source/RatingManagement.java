import java.util.*;

import javax.swing.ListModel;

import java.io.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Array;

public class RatingManagement {
    private ArrayList<Rating> ratings;
    private ArrayList<Movie> movies;
    private ArrayList<User> users;

    public static void HUYSORT(List<String> list) {
        int huy = list.size();
        boolean huy_swap;
        do {
            huy_swap = false;
            for (int i = 1; i < huy; i++) {
                if (list.get(i - 1).compareTo(list.get(i)) > 0) {
                    String temp = list.get(i - 1);
                    list.set(i - 1, list.get(i));
                    list.set(i, temp);
                    huy_swap = true;
                }
            }
            huy--;
        } while (huy_swap);
    }

    public Movie findMovieById(int id) {
        for (Movie movie : movies) {
            if (movie.getId() == id) {
                return movie;
            } else if (String.valueOf(movie.getId()).equals(id)) {
                return movie;
            }
        }
        return null;
    }

    public static ArrayList<Integer> get_HUY_Favorites() {
        return null;
    }

    public ArrayList<Movie> getMovies() {
        return movies;
    }

    public ArrayList<User> getUsers() {
        return users;
    }

    public ArrayList<Rating> getRating() {
        return ratings;
    }

    // @Requirement 1
    public RatingManagement(String moviePath, String ratingPath, String userPath) {
        this.movies = loadMovies(moviePath);
        this.users = loadUsers(userPath);
        this.ratings = loadEdgeList(ratingPath);
    }

    private ArrayList<Rating> loadEdgeList(String ratingPath) {
        ArrayList<Rating> loadRatingEdge = new ArrayList<>();
        String dongLine;

        try (BufferedReader readB = new BufferedReader(new FileReader(ratingPath))) {
            while ((dongLine = readB.readLine()) != null && !dongLine.isEmpty()) {
                String[] prt = dongLine.split(",");
                String[] prt2 = dongLine.split("::");

                try {
                    loadRatingEdge.add(new Rating(Integer.parseInt(prt[0]),
                            Integer.parseInt(prt[1]),
                            Integer.parseInt(prt[2]),
                            Long.parseLong(prt[3]), "error"));
                } catch (NumberFormatException errors) {
                    // errors.printStackTrace();
                    System.err.println("Invalid: " + dongLine);

                }
            }
        } catch (IOException errors) {
            System.err.println("Error: " + errors.getMessage());
            System.out.println("IOException");
        }
        return loadRatingEdge;
    }

    private ArrayList<Movie> loadMovies(String moviePath) {
        ArrayList<Movie> loadMovieEdge = new ArrayList<>();

        try (Scanner readB = new Scanner(new File(moviePath))) {
            readB.nextLine();
            while (readB.hasNextLine() && !readB.equals(null)) {
                String line = readB.nextLine();
                String[] prt = line.split(",");
                if (prt.length >= 3) {
                    try {
                        int idHMovie = Integer.parseInt(prt[0]);
                        String nameHMovie = prt[1];
                        List<String> genresHMovie = List.of(prt[2].split("-,"));

                        Movie movie = new Movie(idHMovie, nameHMovie, new ArrayList<>(genresHMovie));
                        loadMovieEdge.add(movie);

                    } catch (NumberFormatException errors) {
                        errors.printStackTrace();
                        System.err.println("Invalid: " + line);

                    }
                } else {
                    System.err.println("Invalid line format: " + line);
                }
            }
        } catch (IOException errors) {
            errors.printStackTrace();
            new FileNotFoundException("File not found");
        }
        return loadMovieEdge;
    }

    private ArrayList<User> loadUsers(String userPath) {
        ArrayList<User> loadUserEdge = new ArrayList<>();

        try (Scanner readB = new Scanner(new File(userPath))) {
            readB.nextLine();
            while (readB.hasNextLine()) {
                String line = readB.nextLine();
                String[] prt = line.split(",");

                if (prt.length == 5 && prt.length > 4 && prt.length < 6) {
                    try {
                        int idHUser = Integer.parseInt(prt[0]);
                        String genderHUser = prt[1];
                        int ageHUser = Integer.parseInt(prt[2]);
                        String occupationHUser = prt[3];
                        String zipCodeHUser = prt[4];

                        // User userEdge = new User(idUser, genderUser, ageUser, occupationUser,
                        // zipCodeUser);
                        // loadUserEdge.add(userEdge)
                        loadUserEdge.add(new User(idHUser, genderHUser, ageHUser, occupationHUser, zipCodeHUser));
                    } catch (NumberFormatException errors) {
                        errors.printStackTrace();
                    }
                } else {
                    System.err.println("Invalid line format: " + line);
                }
            }
        } catch (IOException errors) {
            errors.printStackTrace();
        }

        return loadUserEdge;
    }

    // @Requirement 2

    public static void HUY2SORT(List<Movie> movies) {
        movies.sort((movie1, movie2) -> movie1.getName().compareToIgnoreCase(movie2.getName()));
    }

    public ArrayList<Movie> findMoviesByNameAndMatchRating(int userId, int rating) {
        ArrayList<Movie> nameRatingMatch = new ArrayList<>();
        ArrayList<Rating> ratings = getRating();
        ListModel<Movie> model_movie = null;

        for (Rating ratingObj : ratings) {
            if (ratingObj.getUserId() == userId && ratingObj.getRatingScore() >= rating
                    && ratingObj.getRatingScore() <= 10) {
                for (Movie movie : movies) {
                    if (movie.getId() == ratingObj.getMovieId() && !nameRatingMatch.contains(movie)
                            && ratingObj.getRatingScore() != 0 && ratingObj.getRatingScore() >= 0) {
                        nameRatingMatch.add(movie);
                        break;
                    } else if (movie.getId() == ratingObj.getMovieId() && !nameRatingMatch.contains(movie)
                            && ratingObj.getRatingScore() != 1 && ratingObj.getRatingScore() >= 4) {

                    } else if (String.valueOf(movie.getId()).equals(ratingObj.getMovieId())
                            && !nameRatingMatch.contains(movie) && ratingObj.getRatingScore() != 0) {
                        nameRatingMatch.add(movie);
                        break;
                    } else {
                        continue;
                    }
                }
            }
        }
        HUY2SORT(nameRatingMatch);
        return nameRatingMatch;
    }

    // Requirement 3
    public ArrayList<User> findUsersHavingSameRatingWithUser(int userId, int movieId) {
        ArrayList<User> nguoiDungChungRating = new ArrayList<>();
        ArrayList<Rating> ratings = getRating();
        ArrayList<User> u_Huy = getUsers();
        ArrayList<Movie> huy_yc4_1 = new ArrayList<Movie>();

        double URating = 0;
        for (Rating huy_rated : ratings) {
            if (huy_rated.getUserId() == userId && huy_rated.getMovieId() == movieId
                    && huy_rated.getRatingScore() != 0) {
                URating = huy_rated.getRatingScore();
                break;
            } else if (huy_yc4_1.isEmpty() && huy_rated.getTimestamp() == movieId
                    && huy_rated.getRatingScore() == 0) {

            } else {
                URating = 0.0;
            }
        }
        for (Rating rated : ratings) {

            if (nguoiDungChungRating.size() >= 1000) {
                break;
            } else if ((rated.getMovieId() == movieId && rated.getUserId() != userId)
                    && rated.getRatingScore() == URating ||
                    (rated.getMovieId() == movieId && rated.getRatingScore() == URating)
                    || (rated.getMovieId() == movieId && userId == rated.getUserId()
                            || movieId == rated.getMovieId())) {
                User nullpoint = null;
                User timUser = nullpoint;
                for (User huy3 : users) {
                    if (huy3.getId() == rated.getUserId() || String.valueOf(huy3.getId()).equals(rated.getUserId())) {

                        timUser = huy3;
                        break;
                    }
                }
                for (User huy4 : nguoiDungChungRating) {
                    if (huy4.getId() == timUser.getId()) {
                        timUser = nullpoint;
                        break;
                    }
                }
                if (timUser != null && !nguoiDungChungRating.contains(timUser)) {
                    nguoiDungChungRating.add(timUser);
                }

            }
        }
        return nguoiDungChungRating;
    }

    // Requirement 4
    public ArrayList<String> findMoviesNameHavingSameReputation() {
        Map<Integer, List<Integer>> userFavorites = NguoiDungYeuThich();
        ArrayList<String> re_huy4 = new ArrayList<>();

        for (Movie huy_yc4 : movies) {
            if (userFavorites.containsKey(huy_yc4.getId())) {
                List<Integer> favoriteMovies = userFavorites.get(huy_yc4.getId());
                List<Deque> favoriteMovies2 = new ArrayList<>();
                if (favoriteMovies != null) {
                    switch (favoriteMovies.size()) {
                        case 0:

                            continue;
                        case 1:
                        default:
                            re_huy4.add(huy_yc4.getName());
                            break;
                    }
                } else if (favoriteMovies != null && favoriteMovies.size() == 1) {
                    re_huy4.add(huy_yc4.getName());
                } else {
                    continue;
                }
            }
        }
        Collections.sort(re_huy4, new Comparator<String>() {
            @Override
            public int compare(String shuy1, String shuy2) {
                return shuy1.compareToIgnoreCase(shuy2);
            }
        });
        HUY2SORT(movies);

        return re_huy4;
    }

    private Map<Integer, List<Integer>> NguoiDungYeuThich() {
        Map<Integer, List<Integer>> NguoiDungYeuThich = new HashMap<>();
        Map<Integer, Movie> mvIDMp = createmvIDMp(movies);

        for (Rating rating : ratings) {
            if (rating.getRatingScore() > 2) {
                int huy_user_id = rating.getUserId();
                if (!NguoiDungYeuThich.containsKey(huy_user_id) && rating.getRatingScore() > 2) {
                    NguoiDungYeuThich.put(huy_user_id, new ArrayList<Integer>());
                    mvIDMp.put(rating.getMovieId(), findMovieById(rating.getMovieId()));
                } else {
                    continue;
                }
                NguoiDungYeuThich.get(huy_user_id).add(rating.getMovieId());
            }
        }

        return NguoiDungYeuThich;
    }

    // Requirement 5
    public ArrayList<String> findMoviesMatchOccupationAndGender(String occupation, String gender, int k,
            int rating) {
        ArrayList<String> huy_yc5 = new ArrayList<>();
        ArrayList<Rating> ratings = getRating();
        ArrayList<User> users = getUsers();
        for (User huy_yc5_1 : users) {
            if (huy_yc5_1.getOccupation().equals(occupation) && huy_yc5_1.getGender().equals(gender) && k > 0) {
                for (Rating userRating : ratings) {
                    if (userRating.getUserId() == huy_yc5_1.getId() && userRating.getRatingScore() == rating) {
                        Movie movie = findMovieById(userRating.getMovieId());
                        if (movie != null && !huy_yc5.contains(movie.getName())) {
                            huy_yc5.add(movie.getName());
                        } else {
                            continue;
                        }
                    }
                }

            }
        }
        HUYSORT(huy_yc5);

        if (huy_yc5.size() > k) {
            huy_yc5 = new ArrayList<>(huy_yc5.subList(0, k));
        }

        return huy_yc5;
    }

    // Requirement 6
    private Map<Integer, Movie> createmvIDMp(List<Movie> movies) {
        Map<Integer, Movie> mvIDMp = new HashMap<>();
        for (Movie movie : movies) {
            mvIDMp.put(movie.getId(), movie);
        }
        return mvIDMp;
    }

    public ArrayList<String> findMoviesByOccupationAndLessThanRating(String occupation, int k, int rating) {
        ArrayList<String> huy_yc6 = new ArrayList<>();
        ArrayList<Rating> ratings = getRating();
        ArrayList<User> users = getUsers();
        ArrayList<Movie> movies = getMovies();
        Map<Integer, Movie> mvIDMp = createmvIDMp(movies);

        for (User huy_user_id : users) {
            if (huy_user_id.getOccupation().equals(occupation) && huy_user_id.getAge() > 0
                    && huy_user_id.getAge() < 97) {
                for (Rating userRating : ratings) {
                    if (userRating.getRatingScore() == 0) {
                        continue;
                    } else if (userRating.getUserId() == huy_user_id.getId() && userRating.getRatingScore() < rating
                            && userRating.getRatingScore() != 0) {
                        Movie movi_HUY1 = findMovieById(userRating.getMovieId());
                        HashMap<Integer, Integer> huy_yc6_1 = new HashMap<>();
                        HashSet<String> movie_HUYNames = new HashSet<>(huy_yc6);
                        if (movi_HUY1 != null && !huy_yc6.contains(movi_HUY1.getName())) {
                            huy_yc6.add(movi_HUY1.getName());
                            // huy_yc6.remove(rating);
                        }
                        if (huy_yc6.size() >= k + 10) {
                            break;
                        } else {
                            continue;
                        }

                    }

                }
            }
        }
        HUYSORT(huy_yc6);

        if (huy_yc6.size() > k) {
            huy_yc6 = new ArrayList<>(huy_yc6.subList(0, k));
        }

        return huy_yc6;
    }

    // @Requirement 7
    public ArrayList<String> findMoviesMatchLatestMovieOf(int userId, int rating, int k) {
        /* code here */
        ArrayList<Rating> HUY_findMoviesMatchLatestMovieOf = new ArrayList<>();
        if (HUY_findMoviesMatchLatestMovieOf.isEmpty()) {
            return new ArrayList<>();
        }

        return new ArrayList<>();
        // return null; /* change here */
    }

}
