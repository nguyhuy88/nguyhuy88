public class Array {
    public static void main(String args[]) {
        String s1 = "so nguyen to";
        char ch[] = { 'h', 'u', 'y' };
        String s2 = new String(ch);
        System.out.println(s1);
        System.out.println(s2);
    }
}
