import java.util.StringTokenizer; // tach chuoi

public class nameInformation {
    public static void main(String[] args) {
        String ten_DayDu = "Nguyen Tran Minh Tuan";
        System.out.println(ten_DayDu);

        int demTu = count_Words(ten_DayDu);
        System.out.println("1) Count: " + demTu);

        String lastName = Last_Name(ten_DayDu);
        System.out.println("2) " + lastName);

    }

    // hàm đếm
    public static int count_Words(String ten_DayDu) {
        StringTokenizer tokenizer = new StringTokenizer(ten_DayDu);
        return tokenizer.countTokens();
    }

    // tách chuỗi cuối của mảng
    public static String Last_Name(String ten_DayDu) {
        StringTokenizer tokenizer = new StringTokenizer(ten_DayDu);
        String lastName = "";
        while (tokenizer.hasMoreTokens()) {
            lastName = tokenizer.nextToken();
        }
        return lastName;
    }
}
