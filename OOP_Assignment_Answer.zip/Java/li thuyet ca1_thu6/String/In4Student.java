import java.util.Scanner;

public class In4Student {
    public static void main(String[] args) {
    }

    public static void cau1() {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter your name: ");
        String name = sc.nextLine();

        System.out.print("Enter your date of birth (DD/MM/YYYY): ");
        String Date = sc.nextLine();

        System.out.print("Enter your student ID: ");
        int id = sc.nextInt();

        System.out.println("Name: " + name);
        System.out.println("Date of birth: " + Date);
        System.out.println("Student ID: " + id);
    }

}