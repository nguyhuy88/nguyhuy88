public class Villa extends DichVuLuuTru {
    private String tenVilla;
    private int soPhongNgu;
    
    public Villa(String viTri, double giaCoBan, String tenVilla, int soPhongNgu) {
      super(viTri, giaCoBan);
      this.tenVilla = tenVilla;
      this.soPhongNgu = soPhongNgu;
    }
    
    public double tinhGiaThueCoBan() {
      double giaThue = giaCoBan + 3000000;
      if (soPhongNgu <= 2) {
        return giaThue;
      } else if (soPhongNgu <= 5) {
        return giaThue + (soPhongNgu - 2) * 2000000;
      } else {
        return giaThue + 3 * 2000000 + (soPhongNgu - 5) * 1000000;
      }
    }
  }
  