public class Test {
    public static void main(String[] args) {
      DichVuLuuTru dvl = new DichVuLuuTru("Vung Tau", 1000000);
      System.out.println("Gia thue DichVuLuuTru: " + dvl.tinhGiaThue()); // output: 1100000.0
      
      KhachSan ks = new KhachSan("Nha Trang", 2000000, "ABC Hotel", 3);
      System.out.println("Gia thue KhachSan: " + ks.tinhGiaThueVCoBan()); // output: 6600000.0
      
      Villa villa = new Villa("Da Nang", 5000000, "XYZ Villa", 6);
      System.out.println("Gia thue Villa: " + villa.tinhGiaThueCoBan()); // output: 12000000.0
    }
  }
  