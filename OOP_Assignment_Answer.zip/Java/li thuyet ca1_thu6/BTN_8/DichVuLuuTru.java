abstract class DichVuLuuTru {
    protected String viTri;
    protected double giaCoBan;
    
    public DichVuLuuTru(String viTri, double giaCoBan) {
      this.viTri = viTri;
      this.giaCoBan = giaCoBan;
    }
    
    public double tinhThue() {
      if (viTri.equals("Vung Tau") || viTri.equals("Nha Trang")) {
        return  0.1;
      } else {
        return  0.05;
      }
    }
    abstract public double tinhThueGiaCoBan();
    
   
  }
  