import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Nhập kích thước mảng
        System.out.print("Nhap so luong phan tu: ");
        int n = scanner.nextInt();

        int[] arr = new int[n];

        // Nhập giá trị cho từng phần tử trong mảng
        System.out.println("Nhap cac phan tu:");
        for (int i = 0; i < n; i++) {
            System.out.print("arr[" + i + "] = ");
            arr[i] = scanner.nextInt();
        }

        // Xuất mảng
        System.out.println("Mang ban vua nhap:");
        for (int i = 0; i < n; i++) {
            System.out.println("arr[" + i + "] = " + arr[i]);
        }

        // Liệt kê âm, dương
        System.out.println("So duong trong mang:");
        for (int i = 0; i < n; i++) {
            if (arr[i] > 0) {
                System.out.println(arr[i]);
            }
        }

        System.out.println("So am trong mang:");
        for (int i = 0; i < n; i++) {
            if (arr[i] < 0) {
                System.out.println(arr[i]);
            }
        }

        // Tìm kiếm phần tử x đầu tiên trong mảng
        System.out.print("Nhap cac  phan tu can tim kiem: ");
        int x = scanner.nextInt();
        int index = -1;

        for (int i = 0; i < n; i++) {
            if (arr[i] == x) {
                index = i;
                break;
            }
        }

        if (index != -1) {
            System.out.println("Phan tu " + x + " duoc tim thay  tai vi tri " + index);
        } else {
            System.out.println("Phan tu " + x + " khong co o mang");
        }

        // Tìm kiếm phần tử âm đầu tiên trong mảng
        int firstNegative = -1;

        for (int i = 0; i < n; i++) {
            if (arr[i] < 0) {
                firstNegative = arr[i];
                break;
            }
        }

        if (firstNegative != -1) {
            System.out.println("Phan tu dau tien:  " + firstNegative);
        } else {
            System.out.println("khong tim thay phan tu am ");
        }
    }
}

