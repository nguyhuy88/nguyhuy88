import java.util.Scanner;

public class test {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Nhập kích thước mảng
        int n = 10;

        int[] arr = {16, 3, 15, 17, 2, 10, 18, 5, 12, 14};

        // Xuất mảng
        System.out.print("mang gom: [");
        for (int i = 0; i < n; i++) {
            System.out.print(arr[i]);
            if (i != n - 1) {
                System.out.print(", ");
            }
        }
        System.out.println("]");

        // Liệt kê âm, dương
        System.out.println("so duong trong mang:");
        for (int i = 0; i < n; i++) {
            if (arr[i] > 0) {
                System.out.println(arr[i]);
            }
        }

        System.out.println("so am trong mang:");
        for (int i = 0; i < n; i++) {
            if (arr[i] < 0) {
                System.out.println(arr[i]);
            }
        }

        // Tìm kiếm phần tử x đầu tiên trong mảng
        int x = 17;
        int index = -1;

        for (int i = 0; i < n; i++) {
            if (arr[i] == x) {
                index = i;
                break;
            }
        }

        if (index != -1) {
            System.out.println("phan tu" + x + " o vi tri " + index);
        } else {
            System.out.println("phan tu " + x + " ko co o mang");
        }

        // Tìm kiếm phần tử âm đầu tiên trong mảng
        int firstNegative = -1;

        for (int i = 0; i < n; i++) {
            if (arr[i] < 0) {
                firstNegative = arr[i];
                break;
            }
        }

        if (firstNegative != -1) {
            System.out.println("phan tu am dau tien : " + firstNegative);
        } else {
            System.out.println("ko co phan tu");
        }
    }
}
