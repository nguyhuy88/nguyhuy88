public class HUY {
    public static int Tvalue(int value) {
        return value;
    }

        public static void main(String[] args) {
            int getValue = HUY.Tvalue(5);
            System.out.println(getValue);
        }
    
}
