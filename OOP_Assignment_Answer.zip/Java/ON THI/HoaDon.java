public class HoaDon {
    private String maHoaDon;
    private String ngayLapHoaDon;
    private String nguoiBan;
    private String nguoiMua;
    private String tenSanPham;
    private int soLuong;
    private double donGia;
    
    public HoaDon() {
        maHoaDon = "HD001";
        nguoiBan = "Nguyen Hoang";
        nguoiMua = "Ho va ten SV";
        tenSanPham = "But bi Thien Long";
        soLuong = 20;
        donGia = 2500;
    }
    
   public  double thanhTien(){
    double thanhTien = soLuong * donGia;

    if(soLuong > 1000){
        double giamGia = thanhTien*0.04;
        thanhTien -= giamGia;
    }return thanhTien;

   }
}
