public class testCircle1 {
    public static void main(String[] args) {
        Circle1 circle1 = new Circle1();
        System.out.println(circle1);
        Circle1 circle2 = new Circle1(2.5, "blue");
        System.out.println(circle2);
        circle1.setRadius(3.5);
        circle1.setColor("xanh");
        System.out.println(circle1);
        System.out.println("dien tich hinh tron2: " + circle2.getArea());

        Cylinder cylinder1 = new Cylinder();
        System.out.println(cylinder1);

        Cylinder cylinder2 = new Cylinder(2.0);
        System.out.println(cylinder2);
        Cylinder cylinder3 = new Cylinder(2.0, 4.0);
        System.out.println(cylinder3);

        Cylinder cylinder4 = new Cylinder(2.0, 4.0, "yellow");
        System.out.println(cylinder4);

        cylinder1.setRadius(3.5);
        cylinder1.setColor("vang");

    }
}
