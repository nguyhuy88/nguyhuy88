public class TestPoint1 {
    public static void main(String[] args) {
        
        Point2D point2D = new Point2D();
        System.out.println(point2D);
        Point3D point3D = new Point3D();
        System.out.println(point3D);
        System.out.println(" Point2D: ");
        
        point2D.setX(2.5f);
        point2D.setY(3.5f);
        System.out.println(point2D);
        System.out.println(" Point3D: ");
    
        point3D.setX(1.5f);
        point3D.setY(4.5f);
        point3D.setZ(-2.1f);
        System.out.println(point3D);
        System.out.println(" XY,XYZ: ");
        point3D.setXY(-1.5f, 5.5f);
        System.out.println(point3D);
        point3D.setXYZ(3.5f, -2.5f, 1.5f);
        System.out.println(point3D);
    }
}
