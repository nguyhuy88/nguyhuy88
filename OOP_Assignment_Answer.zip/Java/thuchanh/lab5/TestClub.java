public class TestClub {
    public static void main(String[] args) {

        Club c1 = new Club();
        Club c2 = new Club("...............", 0, 0, 99);
        Club c3 = new Club(c2);

        System.out.println(c1.getName());
        c1.setName("........");
        System.out.println(c1.getName());
        System.out.println(c2.getWins());
        c2.setWins(6);
        System.out.println(c2.getWins());

        System.out.println(c3.numMatchesPlayed());

        System.out.println(c2.isFinish());

        System.out.println(c2.getPoints());

        System.out.println(c3.toString());
    }
}
