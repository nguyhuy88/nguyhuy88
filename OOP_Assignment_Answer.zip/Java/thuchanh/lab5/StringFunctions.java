import java.util.Scanner;

public class StringFunctions {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a string: ");
        String input = sc.nextLine();
        System.out.println("ten viet tat: " + shortName(input));
        System.out.println("tag ten: " + hashtagName(input));
        System.out.println("in hoa: " + upperCaseAllVowel(input));
        System.out.println("in hoa chu ' N '': " + upperCaseAllN(input));
        sc.close();
    }

    public static String shortName(String str) {
        String[] names = str.split(" ");
        String firstName = names[names.length - 1];
        String lastName = names[0];
        return firstName + " " + lastName;
    }

    public static String hashtagName(String str) {
        String[] names = str.split(" ");
        String firstName = names[names.length - 1];
        String lastName = names[0];
        String hashtagName = "#" + firstName + lastName;
        return hashtagName;
    }

    public static String upperCaseAllVowel(String str) {
        String vowels = "aeiouAEIOU";
        char[] chars = str.toCharArray();
        for (int i = 0; i < chars.length; i++) {
            char c = chars[i];
            if (vowels.indexOf(c) != -1) {
                chars[i] = Character.toUpperCase(c);
            }
        }
        return new String(chars);
    }

    public static String upperCaseAllN(String str) {
        char[] chars = str.toCharArray();
        for (int i = 0; i < chars.length; i++) {
            char c = chars[i];
            if (c == 'n' || c == 'N') {
                chars[i] = Character.toUpperCase(c);
            }
        }
        return new String(chars);
    }

}
