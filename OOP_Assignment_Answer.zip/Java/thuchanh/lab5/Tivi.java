public class Tivi {
    private String maTivi;
    private String hangSanXuat;
    private int soInch;
    private double giaNhap;

    public Tivi() {
        this.soInch = 43;
        this.maTivi = "43UJ633T";
        this.hangSanXuat = "LG";

    }

    public Tivi(int soInch, String maTivi, String hangSanXuat, double giaNhap) {
        this.maTivi = maTivi;
        this.hangSanXuat = hangSanXuat;
        if (soInch == 32 || soInch == 40 || soInch == 43 || soInch == 49 || soInch == 50 || soInch == 55) {
            this.soInch = soInch;
        } else {
            this.soInch = 32;
        }
        this.giaNhap = giaNhap;
    }

    public void xuatThongTin() {
        System.out.println("Ma TiVi: " + maTivi);
        System.out.println("Hang san xuat: " + hangSanXuat);
        System.out.println("so inch cua tv: " + soInch);
        System.out.println("Gia nhap hang: " + giaNhap);
    }

    public String getMaTivi() {
        return maTivi;
    }

    public void setMaTivi(String maTivi) {
        this.maTivi = maTivi;
    }

    public String getHangSanXuat() {
        return hangSanXuat;
    }

    public void setHangSanXuat(String hangSanXuat) {
        this.hangSanXuat = hangSanXuat;
    }

    public int getSoInch() {
        return soInch;
    }

    public void setSoInch(int soInch) {
        if (soInch == 32 || soInch == 40 || soInch == 43 || soInch == 49 || soInch == 50 || soInch == 55) {
            this.soInch = soInch;
        } else {
            this.soInch = 32;// set mac dinh loai inch neu so inch input NGOAI
        }
    }

    public double getGiaNhap() {
        return giaNhap;
    }

    public void setGiaNhap(double giaNhap) {
        this.giaNhap = giaNhap;
    }
}

