import java.util.Scanner;

public class Array1 {
    public static int maxEven(int[] a) {
        int max = Integer.MIN_VALUE;
        for (int i = 0; i < a.length; i++) {
            if (a[i] % 2 == 0 && a[i] > max) {
                max = a[i];
            }
        }
        return max;
    }

    public static int minOdd(int[] a) {
        int min = Integer.MAX_VALUE;
        for (int i = 0; i < a.length; i++) {
            if (a[i] % 2 == 1 && a[i] < min) {
                min = a[i];
            }
        }
        return min;
    }

    public static int sumMEMO(int[] a) {
        int maxEven = maxEven(a);
        int minOdd = minOdd(a);
        return maxEven + minOdd;
    }

    public static int sumEven(int[] a) {
        int sum = 0;
        for (int i = 0; i < a.length; i++) {
            if (a[i] % 2 == 0) {
                sum += a[i];
            }
        }
        return sum;
    }

    public static int prodOdd(int[] a) {
        int prod = 1;
        for (int i = 0; i < a.length; i++) {
            if (a[i] % 2 == 1) {
                prod *= a[i];
            }
        }
        return prod;
    }

    public static int idxFirstEven(int[] a) {
        for (int i = 0; i < a.length; i++) {
            if (a[i] % 2 == 0) {
                return i;
            }
        }
        return -1;
    }

    public static int idxLastOdd(int[] a) {
        for (int i = a.length - 1; i >= 0; i--) {
            if (a[i] % 2 == 1) {
                return i;
            }
        }
        return -1;
    }

    public static int[] input(int n) {
        int[] a = new int[n];
        Scanner scanner = new Scanner(System.in);
        scanner.close();
        for (int i = 0; i < n; i++) {
            System.out.print("Enter element " + (i + 1) + ": ");
            a[i] = scanner.nextInt();
        }
        return a;

    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of elements in the array: ");
        int n = scanner.nextInt();
        int[] a = input(n);

        System.out.println("Array: " + java.util.Arrays.toString(a));
        System.out.println("Max even: " + maxEven(a));
        System.out.println("Min odd: " + minOdd(a));
        System.out.println("Sum of max even and min odd: " + sumMEMO(a));
        System.out.println("Sum of even numbers: " + sumEven(a));
        System.out.println("After odd numbers: " + prodOdd(a));
        System.out.println("Index 1: " + idxFirstEven(a));
        System.out.println("Index 2: " + idxLastOdd(a));
        scanner.close();
    }
}
