class Cau1 {
    public static int sumEvenPos(int a[]) {
        int sum = 0;
        for (int i = 1; i < a.length; i++) {
            if (a[i] % 2 == 0) {
                sum += a[i];

            }
            return sum;
        }
        return -1;
    }

    public static String lowerCaseCharacters(String str) {
        String[] words = str.split("\\s+");
        StringBuilder result = new StringBuilder();
        for (String word : words) {
            result.append(word.toLowerCase()).append(" ");
        }
        return result.toString().trim();
    }

    public static void main(String[] args) {
        int a[] = { 1, -2, 3, 1, -2, 6 };//tinhtong
        System.out.println(sumEvenPos(a));
        String s = "TrUOng DAi Hoc Ton DuC ThAnG";//
        System.out.println(lowerCaseCharacters(s));
    }
}
