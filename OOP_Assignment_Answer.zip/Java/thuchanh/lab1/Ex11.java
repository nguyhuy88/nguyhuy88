public class Ex11 {
    public static int Count_Digits(int number) {
        int count = 0;
        while (number != 0) {
            count++;
            number /= 10;
        }
        return count;
    }

    public static void main(String[] args) {
        int number = 1291838;
        int Count_Digits = Count_Digits(number);
        System.out.println("number be counted: " + number + " = " + Count_Digits + " (Digits) ");
    }
}
