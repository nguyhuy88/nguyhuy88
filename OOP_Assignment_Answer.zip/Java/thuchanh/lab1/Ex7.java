import java.util.Scanner;

public class Ex7 {
    public static boolean check(char c) {
        for (int i = '0'; i <= '9'; i++) {
            if (i == c)
                return true;

        }
        return false;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Check code input: ");
        char c = sc.next().charAt(0);
        if (check(c) == true)
            System.out.print("NUMBER");
        else
            System.out.print("NOT A NUMBER");
        sc.close();
    }
}