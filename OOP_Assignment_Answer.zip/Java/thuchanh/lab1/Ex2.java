public class Ex2 {
    public static void main(String[] args) {
        double base = 6.2;
        double height = 9.8;

        double area = 0.5 * base * height;
        System.out.println(" The area of triagle is: " + area);

    }
}
