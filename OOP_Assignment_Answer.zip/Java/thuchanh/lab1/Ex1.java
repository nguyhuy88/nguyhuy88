import java.util.Scanner;

public class Ex1 {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);

    System.out.print("Enter your name: ");
    String name = sc.nextLine();

    System.out.print("Enter your date of birth: ");
    String Date = sc.nextLine();

    System.out.print("Enter your student ID: ");
    int id = sc.nextInt();

    System.out.println("Name: " + name);
    System.out.println("Date of birth: " + Date);
    System.out.println("Student ID: " + id);

    sc.close();
  }

}