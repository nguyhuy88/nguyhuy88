
public class Ex10 {
    public static int StartAndEnd(int a) {
        int f_Digit = 0;
        int l_Digit = a % 10;
        while (a > 0) {
            if (a < 10) {
                f_Digit = a;
            }
            a /= 10;
        }
        return f_Digit + l_Digit;
    }

    public static void main(String[] args) {
        System.out.println("The Sum is: " + StartAndEnd(12484848));

    }
}
