import java.util.Scanner;

public class Ex3 {
    public static double division(double a, double b) {
        return a / b;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number 1: ");
        double num_1 = sc.nextDouble();
        System.out.print("Enter the number 2: ");
        double num_2 = sc.nextDouble();
        double result = division(num_1, num_2);
        System.out.println("The result: " + result);
        sc.close();
    }
}
