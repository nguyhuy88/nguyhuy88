import java.util.Scanner;

public class Ex4 {
    public static double temperature_F_to_C(double F) {
        return (F - 32) / 1.8;
    }

    public static double temperatura_C_to_F(double C) {
        return (C * 1.8) + 32;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter C: ");
        double C = sc.nextDouble();
        System.out.print("Enter F: ");
        double F = sc.nextDouble();
        System.out.println("temperaturaCtoF: " + temperatura_C_to_F(C));
        System.out.println("temperaturaFtoc: " + temperature_F_to_C(F));

        sc.close();
    }

}
