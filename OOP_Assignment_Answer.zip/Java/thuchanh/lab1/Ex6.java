public class Ex6 {
    public static void main(String[] args) {
        int a = 99;
        int b = 66;
        int c = 33;

        int min = b;

        if (a < min) {
            min = a;
        }
        if (c < min) {
            min = c;
        }

        System.out.println("Min of three numbers is: " + min);

    }
}
