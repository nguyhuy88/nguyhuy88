import java.util.Scanner;
import java.lang.Math;

public class Ex8 {
    public static int sum(int n) {
        int sum = 0;
        for (int i = 1; i <= n; i++)
            sum += i;
        return sum;
    }

    public static int mul(int n) {
        int sum = 1;
        for (int i = 1; i <= n; i++)
            sum *= i;
        return sum;
    }

    public static int mux(int n) {
        int sum = 1;
        for (int i = 1; i <= n; i++)
            sum += Math.pow(2, i);
        return sum;
    }

    public static double div(int n) {
        double sum = 0.0;
        for (int i = 1; i <= n; i++)
            sum += 1.0 / 2 * i;
        return sum;

    }

    public static long xm(int n) {
        int sum = 0;
        for (int i = 1; i <= n; i++)
            sum += Math.pow(i, 2);
        return sum;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Nhap gia tri n: ");
        int n = sc.nextInt();
        System.out.println("Tong 1 -> n: " + sum(n));
        System.out.println("Nhan 1-> n: " + mul(n));
        System.out.println("Mu 1+ 2^i: " + mux(n));
        System.out.println("Chia 1/2n: " + div(n));
        System.out.println("Xich ma 1 -> n: " + xm(n));

        sc.close();
    }
}