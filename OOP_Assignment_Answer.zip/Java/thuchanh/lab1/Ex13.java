public class Ex13 {
    public static void main(String[] args) {
        int number = 1232121231;

        boolean isPalindrome = isPalindromeNumber(number);
        if (isPalindrome) {
            System.out.println(number + " is a palindrome number.");
        } else {
            System.out.println(number + " is not a palindrome number.");
        }
    }

    public static boolean isPalindromeNumber(int number) {
        int reversed = 0;
        int orig = number;

        while (number != 0) {
            int digit = number % 100;
            reversed = reversed * 10 + digit;
            number /= 10;
        }

        return orig == reversed;
    }
}
