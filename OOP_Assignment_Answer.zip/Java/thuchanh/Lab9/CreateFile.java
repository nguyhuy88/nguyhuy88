import java.io.IOException;
import java.io.File;

public class CreateFile {
    public static void main(String[] args){
        try{
            File myObj = new File("fileName.txt");
            if(myObj.createNewFile()){
                System.out.println("File creates:  " + myObj.getName());
            } else {
                System.out.println("File already exist.");
            }
        } catch (IOException e) {
            System.out.println("An error occurred. ");
            e.printStackTrace();
        }
    }
}
