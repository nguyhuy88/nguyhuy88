package bt_lab9;

public class CalculatorTest {
    
    public static void main(String[] args) {
        Calculator calculator = new Calculator();
        
        // Testing divide method
        try {
            double result = calculator.divide(6, 2);
            System.out.println("6 / 2 = " + result);
        } catch (ArithmeticException e) {
            System.out.println(e.getMessage());
        } catch (NumberOutOfRangeException e) {
            System.out.println(e.getMessage());
        }
        
        try {
            double result = calculator.divide(6, 0);
            System.out.println("6 / 0 = " + result);
        } catch (ArithmeticException e) {
            System.out.println(e.getMessage());
        } catch (NumberOutOfRangeException e) {
            System.out.println(e.getMessage());
        }
        
        try {
            double result = calculator.divide(1500, 3);
            System.out.println("1500 / 3 = " + result);
        } catch (ArithmeticException e) {
            System.out.println(e.getMessage());
        } catch (NumberOutOfRangeException e) {
            System.out.println(e.getMessage());
        }
        
        // Testing multiply method
        try {
            int result = calculator.multiply(3, 4);
            System.out.println("3 * 4 = " + result);
        } catch (NumberOutOfRangeException e) {
            System.out.println(e.getMessage());
        }
        
        try {
            int result = calculator.multiply(3, 1500);
            System.out.println("3 * 1500 = " + result);
        } catch (NumberOutOfRangeException e) {
            System.out.println(e.getMessage());
        }
    }
}