public class ImageLoader {
    private static ImageLoader instance;
    
    private ImageLoader() {
        // Private constructor to prevent instantiation
    }
    
    public static ImageLoader getInstance() {
        if (instance == null) {
            instance = new ImageLoader();
        }
        return instance;
    }
    
    public String loadImage() {
        return "Loaded successfully.";
    }
    
    public static void main(String[] args) {
        ImageLoader imageLoader = ImageLoader.getInstance();
        String result = imageLoader.loadImage();
        System.out.println(result);
    }
}
