public class Student {
    private String name;
    private String address;
    private String sex;
    private int score;

    public Student(String name, String address, String sex, int score) {
        this.name = name;
        this.address = address;
        this.sex = sex;
        this.score = score;
    }

    public class StudentOperator {
        public void print() {
            System.out.println("Student [" + name + ", " + address + ", " + sex + ", " + score + "]");
        }

        public String type() {
            if (score > 8) {
                return "A";
            } else if (score >= 5 && score <= 8) {
                return "B";
            } else {
                return "C";
            }
        }
    }

    public static void main(String[] args) {
        Student student = new Student("John Doe", "123 Main St", "Male", 7);
        StudentOperator operator = student.new StudentOperator();

        operator.print();
        System.out.println("Type: " + operator.type());
    }
}
