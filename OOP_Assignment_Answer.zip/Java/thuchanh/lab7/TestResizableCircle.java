public class TestResizableCircle {
    public static void main(String[] args) {
        Circle1 c1 = new Circle1(3.9);
        System.out.println("Circle1 with radius: \n[" + c1.getRadius() + " has area " + c1.getArea() + " and perimeter " + c1.getPerimeter() + "]");

        ResizableCircle rc1 = new ResizableCircle(5.0);
        System.out.println("ResizableCircle with radius: \n[ " + rc1.getRadius() + " has area " + rc1.getArea() + " and perimeter " + rc1.getPerimeter() + "]");

        rc1.resize(59);
        System.out.println("After resizing by 50%, ResizableCircle now has radius: \n[" + rc1.getRadius() + ", area " + rc1.getArea() + ", and perimeter " + rc1.getPerimeter() + "]");
    }
}
