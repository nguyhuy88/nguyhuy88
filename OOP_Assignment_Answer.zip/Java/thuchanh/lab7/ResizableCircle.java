public class ResizableCircle extends Circle1 implements Resizable {
    public ResizableCircle() {
        super();
    }

    public ResizableCircle(double radius) {
        super(radius);
    }

    @Override
    public void resize(int percent) {
        double newRadius = getRadius() * (percent / 100.0);
        setRadius(newRadius);
    }
}