public class e {
    public static void main(String[] args) {
        String str = "Hello world";
        String newWord = "beautiful";
        int insertIndex = 6;
        String newStr = str.substring(0, insertIndex) + newWord + str.substring(insertIndex);
        System.out.println(newStr);

    }
}