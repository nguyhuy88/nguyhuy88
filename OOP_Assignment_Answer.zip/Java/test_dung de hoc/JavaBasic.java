public class JavaBasic {
    public static int sumNegativeElements(int a[]) {
        int sum = 0;
        for( int i =0; i < a.length; i++){
            if(a[i] < 0){
                sum += a[i];
            }
        }
        return sum;
    }

    public static String uppercaseFirstVowels(String str) {
        // sinh vien code tai day
    }

    public static int findMinNegativeElement(int a[]) {
        // sinh vien code tai day
    }

    public static String getName(String str) {
        // sinh vien code tai day
    }

    public static int findFirstMod3Element(int[] a) {
        // sinh vien code tai daye
    }

    public static int countString(String str, String k) {
        // sinh vien code tai day
    }

    public static void main(String[] args) {
        int a = { 1, -2, 3, 4, -2, 1, -9 };
        
        // negativeNumberSum
        int sumNegativeNumber = sumNegativeElements(a);
        System.out.println(" Sum of these negative numbers is: " + sumNegativeNumber);

        String s = "nguyen thi uyen an";
        // sinh vien code tai day
        String s1 = "Ho ten: Nguyen Thi Anh Dao";
        // sinh vien code tai day
        String s2 = "Nguyen Phuong Hoang Anh Phuong Oanh";
        // sinh vien code tai day
    }

}