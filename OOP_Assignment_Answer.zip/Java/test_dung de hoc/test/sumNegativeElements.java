public class sumNegativeElements {
    public static int sumNegativeElements1(int a[]) {
        int sum = 0;
        for (int i = 0; i < a.length; i++) {
            if (a[i] < 0) {
                sum += a[i];
            }
        }
        return sum;
    }

    public static void main(String[] args) {
        int[] a = { -2, -4, -6, -8, 2, 4, 8 };
        int sumNagatives = sumNegativeElements1(a);
        System.out.println("ket qua = " + sumNagatives);
    }
}
