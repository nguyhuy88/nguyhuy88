public class Palindrome {
    public static boolean isPalindrome(String str) {
        StringBuilder rc = new StringBuilder(str).reverse();
        return str.equals(rc.toString());

    }

    public static void main(String[] args) {
        String s1 = " huy";
        String s2 = " ngueyn nhat huy";
        System.out.println(s1 + " is true? " + isPalindrome(s2));
        System.out.println(s2 + " is true? " + isPalindrome(s1));
    }
}
