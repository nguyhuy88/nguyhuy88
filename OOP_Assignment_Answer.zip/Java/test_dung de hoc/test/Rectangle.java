public class Rectangle {
    private String name;
    private String color;
    private double width;
    private double length;

    public Rectangle(String name, String color, double wid, double len) {
        this.name = name;
        this.color = color;
        this.width = wid;
        this.length = len;

    }

    public String getName() {

        return name;
    }

    public String getColor() {
        // sinh vien viet code tai day va sua lai gia tri return
        return color;
    }

    public double getWidth() {
        // sinh vien viet code tai day va sua lai gia tri return
        return width;
    }

    public double getLength() {
        // sinh vien viet code tai day va sua lai gia tri return
        return length;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setColor(String color) {
        // sinh vien code tai day
        this.color = color;
    }

    public void setWidth(double width) {
        // sinh vien code tai day
        this.width = width;

    }

    public void setLength(double length) {
        // sinh vien code tai day
        this.length = length;
    }

    public double getPerimeter() {
        // sinh vien viet code tai day va sua lai gia tri return
        return 2 * (width * length);
    }

    public String getType() {
        // sinh vien viet code tai day va sua lai gia tri return
        double area = width * length;
        if (area >= 10) {
            return "A";

        } else {
            if (area >= 5) {
                return "B";

            } else {
                return "C";
            }
        }
    }

    public boolean isSquare() {
        // sinh vien viet code tai day va sua lai gia tri return
        if (width == length) {
            return true;

        } else {
            return false;
        }
    }

    public double calDiagonalLine() {
        // sinh vien viet code tai day va sua lai gia tri return
        return -1;
    }

    public Rectangle resize(double rate) {
        // sinh vien viet code tai day va sua lai gia tri return
        return null;
    }

    public String toString() {
        double area = width * length;
        return "Rectangle[" + name + ", " + length + ", " + width + ", " + area + ", " + getType() + "]";
    }
}