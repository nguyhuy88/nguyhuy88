public class JavaBasic {
    public static int sumNegativeElements(int a[]) {
        int sum = 0;
        for (int i = 0; i < a.length; i++) {
            if (a[i] < 0) {
                sum += a[i];
            }
        }
        return sum;
    }

    public static String uppercaseFirstVowels(String str) {
        StringBuilder sb = new StringBuilder(str);
        for (int i = 0; i < sb.length(); i++) {
            char c = sb.charAt(i);
            if ("aeiouAEIOU".indexOf(c) != -1) {
                sb.setCharAt(i, Character.toUpperCase(c));
                break;
            }
        }
        return sb.toString();
    }

    public static int findMinNegativeElement(int a[]) {
        int min = Integer.MAX_VALUE;
        for (int i = 0; i < a.length; i++) {
            if (a[i] < 0 && a[i] < min) {
                min = a[i];

            }
        }
        return min;
    }

    public static String getName(String str) {
        return str.replace("Ho ten:", "");
    }

    public static int findFirstMod3Element(int[] a) {
        for (int i = 0; i < a.length; i++) {
            if (a[i] % 3 == 0) {
                return i;
            }
        }
        return -1;
    }

    public static int countString(String str, String k) {
        String[] words = str.split("\\W+");
        int count = 0;
        for (String word : words) {
            if (word.equals(k)) {
                count++;
            }
        }
        return count;

    }

    public static void main(String[] args) {
        int[] a = { 1, -2, 4, -2, 1 };
        // tong cac so am trong chuoi
        int sumNegatives = sumNegativeElements(a);
        System.out.println("tong cac so am: " + sumNegatives);

        String s = "nguyen thi uyen an";
        String upperCased = uppercaseFirstVowels(s);
        System.out.println("In hoa nguyen am: " + upperCased);

        int negativeMin = findMinNegativeElement(a);
        System.out.println("Min negative is: " + negativeMin);

        String s1 = "Ho ten: Nguyen Thi Anh Dao";
        String name = getName(s1);
        System.out.println(name);

        int mod3 = findFirstMod3Element(a);
        System.out.println("chia het cho 3:" + mod3);
        String s2 = "Nguyen Phuong Hoang Anh Phuong Oanh Phuong Phuong";
        int countString1 = countString(s2, "Phuong");
        System.out.println("Count String: " + countString1);

    }

}