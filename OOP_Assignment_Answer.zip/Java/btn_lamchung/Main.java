public class Main {
    public static void main(String[] args) {
        DichVuLuuTru1 dv = new KhachSan1("Vung Tau", 1000000, "Huy ngu", 4);
        DichVuLuuTru1 dv1 = new Villa1("Vung Tau", 5000000, "Huy ngu", 6);

        System.out.println(dv.tinhThueGiaCoBan());
        System.out.println(dv1.tinhThueGiaCoBan());
    }
}
