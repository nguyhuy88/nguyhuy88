class KhachSan1 extends DichVuLuuTru1 {
    private String tenKS;
    private int soSao;
    public KhachSan1(String viTri, double giaCoBan, String tenKS, int soSao) {
        super(viTri, giaCoBan);
        this.tenKS = tenKS;
        this.soSao = soSao;
    }
    public double tinhThueGiaCoBan() {
        double giaThue ;
        if (soSao <= 2) giaThue = this.giaCoBan ;
        else giaThue = giaCoBan * 1.1;
        return giaThue + super.tinhThue() * giaThue;
    }

}
