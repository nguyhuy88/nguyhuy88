class Villa1 extends DichVuLuuTru1 {

    
    private String tenVilla;
    private int soPhong;
    public Villa1(String viTri, double giaCoBan, String tenVilla, int soPhong) {
        super(viTri, giaCoBan);
        this.tenVilla = tenVilla;
        this.soPhong = soPhong;
    }

    public double tinhThueGiaCoBan() {
        if (soPhong <= 2) return this.giaCoBan + 3000000;
        else if (soPhong <= 5) return this.giaCoBan + 3000000 + 2000000*(this.soPhong-2);
        else return this.giaCoBan + 3000000 + 2000000*3 + (this.soPhong - 5) * 1000000;
    }
}