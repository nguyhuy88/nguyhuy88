abstract class DichVuLuuTru1 {
    protected String viTri;
    protected double giaCoBan;

    public DichVuLuuTru1(String viTri, double giaCoBan) {
        this.viTri = viTri;
        this.giaCoBan = giaCoBan;
    }
    public double tinhThue() {
        if (viTri.equals("Vung Tau") || viTri.equals("Nha Trang")) {
            return 0.1;
        }
        return 0.05;
    }
    abstract public double tinhThueGiaCoBan();
}