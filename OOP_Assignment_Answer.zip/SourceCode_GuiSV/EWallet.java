public class EWallet implements Payment, Transfer 
{
	// code here
    private int phoneNumber;
    private double balance;

    public EWallet(int phoneNumber) 
    {
        this.phoneNumber = phoneNumber;
        this.balance = 0.0;
    }

    @Override
    public boolean pay(double amount) 
    {
        if (balance >= amount) {
            balance -= amount;
            return true;
        }
        return false;
    }

    @Override
    public double checkBalance() 
    {
        return balance;
    }

    @Override
    public boolean transfer(double amount, Transfer to) 
    {
        double amounttransferFee = amount * transferFee;
        double sotienchuyen = amounttransferFee+amount;
        if (sotienchuyen <= balance) 
        {
            balance -= sotienchuyen;
            if (to instanceof BankAccount)
                ((BankAccount) to).topUp(amount);
            else
                ((EWallet) to).topUp(amount);
            return true;
        }
        return false;
    }
    public void topUp(double amount) 
    {
        balance += amount;
    }
    public int getPhoneNumber() 
    {
        return phoneNumber;
    }
    public void setPhoneNumber(int phoneNumber) 
    {
        this.phoneNumber = phoneNumber;
    }
    public void recharge(double amount) 
    {
        balance += amount;
    }
    public String toString() 
    {
        return String.format("%d,%.1f", phoneNumber, balance);
    }
}
