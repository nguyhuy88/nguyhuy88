public class IDCard {
    private int id;
    private String name;
    private String gender;
    private String birthday;
    private String address;
    private int phone;

    public IDCard(int id, String name, String gender, String birthday, String address, int phone) 
    {
        this.id = id;
        this.name = name;
        this.gender = gender;
        this.birthday = birthday;
        this.address = address;
        this.phone = phone;
    }
    public int getAge() 
    {
        String date = getBirthday();
        int age = 2023 - Integer.parseInt(date.substring(date.length()-4));
	return age;
    }
    public int getId() 
    {
        return id;
    }
    public String getName() 
    {
        return name;
    }
    public String getGender() 
    {
        return gender;
    }
    public String getBirthday() 
    {
        return birthday;
    }
    public String getAddress() 
    {
        return address;
    }
    public int getPhone() 
    {
        return phone;
    }
    public void setId(int id) 
    {
        this.id = id;
    }
    public void setName(String name) 
    {
        this.name = name;
    }
    public void setGender(String gender) 
    {
        this.gender = gender;
    }
    public void setBirthday(String birthday) 
    {
        this.birthday = birthday;
    }
    public void setAddress(String address) 
    {
        this.address = address;
    }
    public void setPhone(int phone)
    {
        this.phone = phone;
    }
    public String toString() 
    {
        return String.format("%06d,%s,%s,%s,%s,%07d", id, name, gender, birthday, address, phone);
    }
}
