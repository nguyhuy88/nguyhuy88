public class BankAccount implements Payment, Transfer
{
    // code here
    private int accountNumber;
    private double interestRate;
    private double balance;
    public BankAccount(int accountNumber, double interestRate) 
    {
        this.accountNumber = accountNumber;
        this.interestRate = interestRate;
        this.balance = 50.0;
    }
    @Override
    public boolean pay(double amount) 
    {
        if(balance >= amount+50) 
        {
            balance -= amount;
            return true;
        }
        return false;
    }
    @Override
    public double checkBalance() 
    {
        return balance;
    }
    @Override
    public boolean transfer(double amount, Transfer to)
    {
        double amounttransferFee = amount * transferFee;
        double sotienchuyen = amounttransferFee+amount;
        if (sotienchuyen + 50 <= balance) 
        {
            balance -= sotienchuyen;
            if (to instanceof BankAccount)
                ((BankAccount) to).topUp(amount);
            else
                ((EWallet) to).topUp(amount);
            return true;
        }
        return false;
    }
    public void topUp(double amount) 
    {
        balance += amount;
    }
    public int getAccountNumber() 
    {
        return accountNumber;
    }

    public double getInterestRate() 
    {
        return interestRate;
    }
    public void setInterestRate(double interestRate) 
    {
        this.interestRate = interestRate;
    }
    public void deposit(double amount) 
    {
        balance += amount;
    }
    public String toString() 
    {
        return String.format("%06d,%.2f,%.1f", accountNumber, interestRate, balance);
    }
}
