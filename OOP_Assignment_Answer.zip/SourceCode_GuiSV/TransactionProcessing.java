import java.util.*;
import java.io.*;

public class TransactionProcessing {
    private ArrayList<Payment> paymentObjects;
    private IDCardManagement idcm;
    
    public TransactionProcessing(String idCardPath, String paymentPath) {
        idcm = new IDCardManagement(idCardPath);
        readPaymentObject(paymentPath);
    
    }

    public ArrayList<Payment> getPaymentObject() {
        return this.paymentObjects;
    }

    // Requirement 3
    public boolean readPaymentObject(String path) {
        //code here
        BufferedReader reader = null;
        paymentObjects = new ArrayList<Payment>();
        ArrayList<IDCard> idCards = idcm.getIDCards();
        try 
        {
            reader = new BufferedReader(new FileReader(path));
            String line = reader.readLine();
            while (line != null) 
            {
                //Integer.parseInt
                String[] values = line.split(",");
                if(values.length == 2)//BankAccount
                {
                    int accountNumber = Integer.parseInt(values[0]);
                    double interestRate = Double.parseDouble(values[1]);
                    BankAccount bc = new BankAccount(accountNumber, interestRate);
                    paymentObjects.add(bc);
                }
                else//ConvenientCard or EWallet
                {
                    if(values[0].length() == 6)// is ConvenientCard
                    {
                        int id = Integer.parseInt(values[0]);
                        IDCard card = null;
                        for (int i = 0; i < idCards.size(); i++) 
                        {
                            card = idCards.get(i);
                            if(card.getId() == id)
                                break;
                        }
                        try
                        {
                            if(card != null)
                            {
                                ConvenientCard cc = new ConvenientCard(card);
                                paymentObjects.add(cc);
                            }
                        }
                        catch(CannotCreateCard e)
                        {
                            
                        }
                    }
                    else // is EWallet
                    {
                        int phoneNumber = Integer.parseInt(values[0]);
                        EWallet ew = new EWallet(phoneNumber);
                        paymentObjects.add(ew);
                    }
                }
                line = reader.readLine();
            }
        } catch (IOException e) 
        {
            return false;
        } 
        finally 
        {
            try 
            {
                if (reader != null) 
                {
                    reader.close();
                }
            } catch (IOException e) 
            {
                return false;
            }
        }
        return true;
    }

    // Requirement 4
    public ArrayList<ConvenientCard> getAdultConvenientCards() 
    {
        //code here
        ArrayList<ConvenientCard> listConvenientCard = new ArrayList<ConvenientCard>();
        ArrayList<Payment> listPayment = getPaymentObject();
        for (int i = 0; i < listPayment.size(); i++) 
        {
            Payment pp = listPayment.get(i);
            if (pp instanceof ConvenientCard)
            {
                ConvenientCard cc = ((ConvenientCard) pp);
                if(cc.getType().equals("Adult"))
                {
                    listConvenientCard.add(cc);
                }
            }
        }
        if(listConvenientCard.size() > 0)
            return listConvenientCard;
        return null;
    }

    // Requirement 5
    public ArrayList<IDCard> getCustomersHaveBoth() {
        //code here
        ArrayList<IDCard> idCards = idcm.getIDCards();
        ArrayList<Payment> listPayment = getPaymentObject();
        ArrayList<IDCard> idCardsResult = new ArrayList<IDCard>();
        for (int i = 0; i < idCards.size(); i++) 
        {
            IDCard card = idCards.get(i);
            int cnt = 0;
            for (int j = 0; j < listPayment.size(); j++) 
            {
                Payment pp = listPayment.get(j);
                if (pp instanceof ConvenientCard)
                {
                    ConvenientCard cc = ((ConvenientCard) pp);
                    if(cc.getIdCard().getId() == card.getId())
                        cnt++;
                }
                else if(pp instanceof BankAccount)
                {
                    BankAccount ba = ((BankAccount) pp);
                    if(ba.getAccountNumber() == card.getId())
                        cnt++;
                }
                else
                {
                    EWallet ew = ((EWallet) pp);
                    if(ew.getPhoneNumber()== card.getPhone())
                        cnt++;
                }
            }
            if(cnt == 3)
                idCardsResult.add(card);
        }
        return idCardsResult;
    }
    public Payment getPayment(String type, int id)
    {
        ArrayList<Payment> listPayment = getPaymentObject();
        for (int j = 0; j < listPayment.size(); j++) 
        {
            Payment pp = listPayment.get(j);
            if(type.equals("BA"))
            {
                if (pp instanceof BankAccount)
                {
                    BankAccount ba = ((BankAccount) pp);
                    if(ba.getAccountNumber() == id)
                        return pp;
                }
            }
            if(type.equals("EW"))
            {
                if (pp instanceof EWallet)
                {
                    EWallet ew = ((EWallet) pp);
                    if(ew.getPhoneNumber()== id)
                        return pp;
                }
            }
            if(type.equals("CC"))
            {
                if (pp instanceof ConvenientCard)
                {
                    ConvenientCard cc = ((ConvenientCard) pp);
                    if(cc.getIdCard().getId()== id)
                        return pp;
                }
            }
        }
        return null;
    }
    // Requirement 6
    public void processTopUp(String path) {
        //code here
        BufferedReader reader = null;
        try 
        {
            reader = new BufferedReader(new FileReader(path));
            String line = reader.readLine();
            while (line != null) 
            {
                String[] values = line.split(",");
                String type = values[0];
                int id = Integer.parseInt(values[1]);
                double amount = Double.parseDouble(values[2]);
                Payment pp = getPayment(type, id);
                if(type.equals("BA"))
                {
                    ((BankAccount) pp).topUp(amount);
                }
                else if(type.equals("EW"))
                {
                    ((EWallet) pp).topUp(amount);
                }
                else if(type.equals("CC"))
                {
                    ((ConvenientCard) pp).receive(amount);
                }
                line = reader.readLine();
            }
        } 
        catch (IOException e) 
        {
        } 
        finally 
        {
            try 
            {
                if (reader != null) 
                {
                    reader.close();
                }
            } catch (IOException e) 
            {
            }
        }
    }

    // Requirement 7
    public ArrayList<Bill> getUnsuccessfulTransactions(String path) {
        //code here
        BufferedReader reader = null;
        ArrayList<Bill> listBillUnsuccess = new ArrayList<Bill>();
        try 
        {
            reader = new BufferedReader(new FileReader(path));
            String line = reader.readLine();
            while (line != null) 
            {
                String[] values = line.split(",");
                int billID = Integer.parseInt(values[0]);
                double total = Double.parseDouble(values[1]);
                String payFor = values[2];
                Bill bill = new Bill(billID,total,payFor);
                String type = values[3];
                int id = Integer.parseInt(values[4]);
                Payment pp = getPayment(type, id);
                if(type.equals("BA"))
                {
                    if(((BankAccount) pp).pay(total) == false)
                        listBillUnsuccess.add(bill);
                }
                else if(type.equals("EW"))
                {
                    if(((EWallet) pp).pay(total) == false)
                        listBillUnsuccess.add(bill);
                }
                else if(type.equals("CC"))
                {
                    if(((ConvenientCard) pp).pay(total) == false)
                        listBillUnsuccess.add(bill);
                }
                line = reader.readLine();
            }
        } 
        catch (IOException e) 
        {
        } 
        finally 
        {
            try 
            {
                if (reader != null) 
                {
                    reader.close();
                }
            } catch (IOException e) 
            {
            }
        }
        return listBillUnsuccess;
    }

    // yeu cau 8
    public ArrayList<BankAccount> getLargestPaymentByBA(String path) {
        //code here
        BufferedReader reader = null;
        ArrayList<BankAccount> listBaSuccess = new ArrayList<BankAccount>();
        
        double max = 0.0;
        try 
        {
            reader = new BufferedReader(new FileReader(path));
            String line = reader.readLine();
            while (line != null) 
            {
                String[] values = line.split(",");
                int billID = Integer.parseInt(values[0]);
                double total = Double.parseDouble(values[1]);
                String payFor = values[2];
                Bill bill = new Bill(billID,total,payFor);
                String type = values[3];
                int id = Integer.parseInt(values[4]);
                Payment pp = getPayment(type, id);
                if(type.equals("BA"))
                {
                    if(((BankAccount) pp).pay(total) == true)
                    {
                        if(bill.getTotal() > max) // check billMax
                        {
                            max = bill.getTotal();
                            listBaSuccess.clear();
                            listBaSuccess.add((BankAccount) pp);
                        }
                        else if(bill.getTotal() == max)
                        {
                            listBaSuccess.add((BankAccount) pp);
                        }
                    }
                }
                line = reader.readLine(); // in while() loop
            }
        } 
        catch (IOException e) 
        {
        } 
        finally 
        {
            try 
            {
                if (reader != null) 
                {
                    reader.close();
                }
            } catch (IOException e) 
            {
            }
        }
        return listBaSuccess;
    }
    public IDCard getIDCardByPhone(int numberPhone)
    {
        ArrayList<IDCard> idCards = idcm.getIDCards();
        for (int i = 0; i < idCards.size(); i++) 
        {
            if(idCards.get(i).getPhone() == numberPhone)
                return idCards.get(i);
        }
        return null;
    }
    //Requirement 9
    public void processTransactionWithDiscount(String path) 
    {
        //code here
        BufferedReader reader = null;
        try 
        {
            reader = new BufferedReader(new FileReader(path));
            String line = reader.readLine();
            while (line != null) 
            {
                String[] values = line.split(",");
                int billID = Integer.parseInt(values[0]);
                double total = Double.parseDouble(values[1]);
                String payFor = values[2];
                Bill bill = new Bill(billID,total,payFor);
                String type = values[3];
                int id = Integer.parseInt(values[4]);
                Payment pp = getPayment(type, id);
                
                if(type.equals("CC"))
                {
                    ((ConvenientCard) pp).pay(total);
                }
                else if(type.equals("BA"))
                {
                    ((BankAccount) pp).pay(total);
                }   
                else if(type.equals("EW"))
                {
                    EWallet ew = (EWallet) pp;
                    if(bill.getPayFor().equals("Clothing") && bill.getTotal() > 500)
                    {
                        IDCard card = getIDCardByPhone(ew.getPhoneNumber());
                        if((card.getGender().equals("Male") && card.getAge() < 20)
                                || (card.getGender().equals("Female") && card.getAge() < 18))
                        {
                            double giamgia = bill.getTotal() - (bill.getTotal() * 0.15);
                            ew.pay(giamgia);
                        }
                        else
                            ew.pay(total);
                    }
                    else
                        ew.pay(total);
                }
                line = reader.readLine();
            }
        } 
        catch (IOException e) 
        {
        } 
        finally 
        {
            try 
            {
                if (reader != null) 
                {
                    reader.close();
                }
            } catch (IOException e) 
            {
            }
        }
    }
}
