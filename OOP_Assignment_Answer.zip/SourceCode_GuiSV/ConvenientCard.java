public class ConvenientCard implements Payment
{
	// code here
    private String type;
    private IDCard idCard;
    private double balance;
    public ConvenientCard(IDCard idCard) throws CannotCreateCard 
    {
        this.idCard = idCard;
        this.balance = 100;
        String date = idCard.getBirthday();
        int age = 2023 - Integer.parseInt(date.substring(date.length()-4));
        //System.out.println(age);
        if(age < 12)
            throw new CannotCreateCard("Not enought age");
        else if(age <= 18)
            this.type ="Student";
        else
            this.type ="Adult";
    }
    
    @Override
    public double checkBalance() 
    {
        return balance;
    }
    @Override
    public boolean pay(double amount) 
    {
        double lephi = 0.0;
        if(this.type.equals("Adult"))
            lephi = amount*0.01;
        double sotienthanhtoan = amount+lephi;
        if (balance >= sotienthanhtoan) 
        {
            balance -= sotienthanhtoan;
            return true;
        }
        return false;
    }
    public void receive(double amount) 
    {
        balance += amount;
    }
    public IDCard getIdCard() 
    {
        return idCard;
    }
    public void setType(String type) 
    {
        this.type = type;
    }

    public void setIdCard(IDCard idCard) 
    {
        this.idCard = idCard;
    }
    public String toString() 
    {
        String strnum = Double.toString(balance);
        if(strnum.length() - (strnum.indexOf(".")+1) >= 2)
            return String.format("%s,%s,%.2f", idCard.toString(), type, balance);
        return String.format("%s,%s,%.1f", idCard.toString(), type, balance);
    }
    public String getType() 
    {
	return this.type;
    }
}
